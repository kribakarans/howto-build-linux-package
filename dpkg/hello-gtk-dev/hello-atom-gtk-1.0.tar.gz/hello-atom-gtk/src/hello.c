#include <stdio.h>
#include <stdlib.h>

int main()
{
	system("zenity --info --title=\"Atom\" --text \"Hello-world !\" --width=200 --timeout=3");

	return 0;
}
