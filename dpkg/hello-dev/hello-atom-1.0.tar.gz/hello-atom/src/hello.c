#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Atom: Hello, world!\n");

	return 0;
}
